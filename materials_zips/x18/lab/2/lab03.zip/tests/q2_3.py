test = {
  'name': 'Question 2.3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> 0 < total_changes
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> total_changes
          45
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
